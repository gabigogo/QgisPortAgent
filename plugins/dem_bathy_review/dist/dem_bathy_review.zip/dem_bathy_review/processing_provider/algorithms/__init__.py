"""Algorithms package for dem_bathy_review."""
